package com.neurogine.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductManagementPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
